

<div id="flash-overlay-modal" class="modal bottom-sheet <?php echo e(isset($modalClass) ? $modalClass : ''); ?>">
        <div class="modal-content">
            <h4><?php echo e($title); ?></h4>
            <div class="modal-body">
                <p><?php echo $body; ?></p>
            </div>
            <div class="modal-footer">
                <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Cerrar</a>
            </div>
        </div>
</div>
