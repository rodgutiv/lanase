<?php $__env->startSection('title','Distribution'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo Form::open(['route' => 'taxonomic.store', 'method' => 'POST']); ?>

<div class="row">
	<div class="col s3">
		<?php echo Form::label('scientific_name', 'scientific_name'); ?>

		<?php echo Form::text('scientific_name', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('canonic_name', 'canonic_name'); ?>

		<?php echo Form::text('canonic_name', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('infra_generic', 'infra_generic'); ?>

		<?php echo Form::text('infra_generic', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('infra_epiteto_specific', 'infra_epiteto_specific'); ?>

		<?php echo Form::text('infra_epiteto_specific', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('rank_marker', 'rank_marker'); ?>

		<?php echo Form::text('rank_marker', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('specific_epithet', 'specific_epithet'); ?>

		<?php echo Form::number('specific_epithet', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('superkingdom', 'superkingdom'); ?>

		<?php echo Form::text('superkingdom', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('kingdom', 'kingdom'); ?>

		<?php echo Form::text('kingdom', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('phylum', 'phylum'); ?>

		<?php echo Form::text('phylum', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('subphylum', 'subphylum'); ?>

		<?php echo Form::text('subphylum', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('superclass', 'superclass'); ?>

		<?php echo Form::text('superclass', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('class', 'class'); ?>

		<?php echo Form::text('class', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('subclass', 'subclass'); ?>

		<?php echo Form::text('subclass', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('infraclass', 'infraclass'); ?>

		<?php echo Form::text('infraclass', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('superorder', 'superorder'); ?>

		<?php echo Form::text('superorder', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('order_2', 'order_2'); ?>

		<?php echo Form::text('order_2', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('suborder', 'suborder'); ?>

		<?php echo Form::text('suborder', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('infraorder', 'infraorder'); ?>

		<?php echo Form::text('infraorder', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('parvorder', 'parvorder'); ?>

		<?php echo Form::text('parvorder', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('superfamily', 'superfamily'); ?>

		<?php echo Form::text('superfamily', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('family', 'family'); ?>

		<?php echo Form::text('family', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('subfamily', 'subfamily'); ?>

		<?php echo Form::text('subfamily', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('tribe', 'tribe'); ?>

		<?php echo Form::text('tribe', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('genus', 'genus'); ?>

		<?php echo Form::text('genus', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('subgenus', 'subgenus'); ?>

		<?php echo Form::text('subgenus', null, ['class' => 'validate', 'required']); ?>

	</div>
	<div class="col s3">
		<?php echo Form::label('subspecie', 'subspecie'); ?>

		<?php echo Form::text('subspecie', null, ['class' => 'validate', 'required']); ?>

	</div>
</div>
<div class="row">
	<?php echo Form::submit('Guardar', ['class'=>'btn btn-large btn-block btn-block-large waves-effect waves-light']); ?>

</div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>