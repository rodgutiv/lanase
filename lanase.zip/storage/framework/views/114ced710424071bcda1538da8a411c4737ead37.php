<?php $__env->startSection('title','Distribution'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo Form::open(['route' => 'distribution.store', 'method' => 'POST']); ?>


<?php echo Form::label('specimen_id', 'Specimen ID'); ?>

<?php echo Form::text('specimen_id', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('latitude', 'Latitude'); ?>

<?php echo Form::text('latitude', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('longitude', 'Longitude'); ?>

<?php echo Form::text('longitude', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('altitude', 'Altitude'); ?>

<?php echo Form::text('altitude', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('site', 'Site'); ?>

<?php echo Form::text('site', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('date', 'Date'); ?>

<?php echo Form::date('date', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('country', 'Country'); ?>

<?php echo Form::text('country', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('region', 'Region'); ?>

<?php echo Form::text('region', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('locality', 'Locality'); ?>

<?php echo Form::text('locality', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::label('sub_locality', 'Sub Locality'); ?>

<?php echo Form::text('sub_locality', null, ['class' => 'validate', 'required']); ?>


<?php echo Form::submit('Guardar', ['class'=>'btn btn-large btn-block btn-block-large waves-effect waves-light']); ?>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>