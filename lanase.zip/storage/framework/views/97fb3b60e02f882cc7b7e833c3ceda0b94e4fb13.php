<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Lanase |  <?php echo $__env->yieldContent('title','Inicio'); ?> </title>

	<?php echo Html::style('http://fonts.googleapis.com/icon?family=Material+Icons'); ?>

	<?php echo Html::style('css/materialize.min.css'); ?>

	<?php echo Html::style('css/font-awesome.css'); ?>

	<?php echo Html::style('css/main.css'); ?>	
</head>
<body>
	
	<header>
		<?php echo $__env->yieldContent('nav'); ?>
	</header>

	<main class="container">
		<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
	</main>

	<?php echo Html::script('js/jquery-3.1.1.min.js'); ?>

	<?php echo Html::script('js/materialize.min.js'); ?>

	<?php echo Html::script('js/scripts.js'); ?>

	<script type="text/javascript">
		
	  <?php if($errors): ?>
	    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	      Materialize.toast('<?php echo e($error); ?>', 4000, 'red white-text');
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  <?php endif; ?>

	</script>
	<script type="text/javascript">
		<?php echo $__env->yieldContent('scripts'); ?>		
	</script>
</body>
</html>