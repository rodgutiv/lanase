<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt-30">
	<div class="col s12 border-bottom">
		<h5><b>Bienvenido <?php echo e(Auth::user()->name); ?></b></h5>
	</div>
</div>
<div class="row">
	<div class="col s6 z-depth-2 nopadding">
		<div class="panel-heading teal">
			<h6><a href="users.php" class="white-text">Usuarios</a></h6>
		</div>
		<div class="panel-body">
			<ul class="collection noborder">
				<li class="collection-item">Total <span class="badge teal br-15 white-text"><?php echo e($users['total']); ?></span></li>
				<li class="collection-item">Activo <span class="badge blue br-15 white-text"><?php echo e($users['activos']); ?></span></li>
				<li class="collection-item">Inactivo <span class="badge orange br-15 white-text"><?php echo e($users['inactivos']); ?></span></li>
			</ul>
		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>