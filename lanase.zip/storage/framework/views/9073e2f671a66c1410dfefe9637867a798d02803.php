<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php if(Auth::user()->isAdmin()): ?>
	<?php echo $__env->make('layouts.nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('layouts.nav-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row mt-30">
		<div class="col s12 border-bottom">
			<h5><b>Proyectos</b></h5>
		</div>
	</div>
		<div class="row">
			<div class="col s12 z-depth-1 white">
				<table class="bordered responsive-table">
					<thead>
						<tr>
							<th>Id</th>
							<th>Nombre (es)</th>
							<th>Research Area</th>
							<th>Responsable</th>
							<th>Display</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody id="table-users-body">
						<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
							<td><?php echo e($project->id); ?></td>
							<td><?php echo e($project->title_es); ?></td>
							<td><?php echo e($project->research_area->title_es); ?></td>					
							<td>
								<?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<?php if($user->pivot->responsible == 1): ?>
										<?php echo e($user->name); ?>

									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</td>					
							<td>
								<?php if( $project->display == 1 ): ?>
								<span class='badge1 teal white-text'>Si</span>
								<?php else: ?>
								<span class='badge1 red white-text'>No</span>
								<?php endif; ?>
							</td>						
							<td>
								<a href="#!" class="user-view" data-id="<?php echo e($project->id); ?>"><i class="material-icons brown-text">receipt</i></a>
								<a href="#!" class="user-edit" data-id="<?php echo e($project->id); ?>"><i class="material-icons teal-text">edit</i></a>
								<a href="#!" class="user-delete" data-id="<?php echo e($project->id); ?>"><i class="material-icons red-text">delete</i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>

		<div class="fixed-action-btn">
		<a href="<?php echo e(route('projects.create')); ?>" class="btn-floating btn-large waves-effect waves-light blue pull-right"><i class="material-icons">add</i></a>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>