<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php if(Auth::user()->isAdmin()): ?>
	<?php echo $__env->make('layouts.nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('layouts.nav-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row mt-30">
		<div class="col s12 border-bottom">
			<h5><b>Areas de investigación</b></h5>
		</div>
	</div>
		<div class="row">
			<div class="col s12 z-depth-1 white">
				<table class="bordered responsive-table">
					<thead>
						<tr>
							<th>Imagen</th>
							<th>Nombre (es)</th>
							<th>Nombre (en)</th>
							<th>Display</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody id="table-users-body">
						<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
							<td width="20%" class="p-1">
								<img src="<?php echo e(asset('/images/researcharea/'.$area->image)); ?>" class="responsive-img">
							</td>
							<td><?php echo e($area->title_es); ?></td>
							<td><?php echo e($area->title); ?></td>						
							<td>
								<?php if( $area->display == 1 ): ?>
								<span class='badge1 teal white-text'>Si</span>
								<?php else: ?>
								<span class='badge1 red white-text'>No</span>
								<?php endif; ?>
							</td>						
							<td>
								<a href="#!" class="user-view" data-id="<?php echo e($area->id); ?>"><i class="material-icons brown-text">receipt</i></a>
								<a href="#!" class="user-edit" data-id="<?php echo e($area->id); ?>"><i class="material-icons teal-text">edit</i></a>
								<a href="#!" class="user-delete" data-id="<?php echo e($area->id); ?>"><i class="material-icons red-text">delete</i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>

		<div class="fixed-action-btn">
		<a href="<?php echo e(route('researcharea.create')); ?>" class="btn-floating btn-large waves-effect waves-light blue pull-right"><i class="material-icons">add</i></a>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>