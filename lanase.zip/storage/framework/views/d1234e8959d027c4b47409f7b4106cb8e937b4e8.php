<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php if(Auth::user()->isAdmin()): ?>
	<?php echo $__env->make('layouts.nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('layouts.nav-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row mt-30">
		<div class="col s12 border-bottom">
			<h5><b>Agregar nuevo usuario</b></h5>
		</div>
	</div>
	<div class="row">
		
		<?php echo Form::open(['route' => 'users.store', 'method' => 'POST', 'class' => 'col s12 white z-depth-1', 'style' => 'padding: 30px']); ?>

			<div class="row">
				<div class="input-field col s12 m6">
					<?php echo Form::label('name', 'Nombre'); ?>

					<?php echo Form::text('name', null, ['class'=>'validate', 'required']); ?>					
				</div>
				<div class="input-field col s12 m6">
					<?php echo Form::label('email', 'Email'); ?>

					<?php echo Form::email('email', null, ['class'=>'validate', 'required']); ?>					
				</div>
			</div>
			<div class="row">
				<div class="input-field col s12 m2">
					<?php echo Form::select('role', ['1' => 'Admin', '2' => 'User'], null, ['class' => 'select-dropdown', 'required', 'id' => 'role', 'placeholder' => 'Seleccione un rol']); ?>

				</div>
				<div class="input-field col s12 m5">
					<?php echo Form::label('password', 'Password'); ?>

					<?php echo Form::password('password', ['class'=>'validate', 'required']); ?>

				</div>
				<div class="input-field col s12 m5">
					<?php echo Form::label('password_confirmation', 'Verifique Password'); ?>

					<?php echo Form::password('password_confirmation', ['class'=>'validate', 'required']); ?>

				</div>
			</div>
			<div class="input-field">
		      <?php echo Form::submit('Guardar',['class'=>'btn btn-block btn-block-large waves-effect waves-light']); ?>

		    </div>
		<?php echo Form::close(); ?>


	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>