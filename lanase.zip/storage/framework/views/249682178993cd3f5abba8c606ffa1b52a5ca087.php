<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
        
    <div class="row mt-150">

            <?php echo Form::open(['url' => 'login', 'method' => 'POST', 'class' => 'col s6 col-center', 'style' => 'padding:30px' ]); ?>


                <div class="row">
                    
                    <div class="input-field col s12">
                        
                        <?php echo Form::label('email', 'Email'); ?>

                        <?php echo Form::email('email', null, ['class' => 'validate', 'required']); ?>


                    </div>

                    <div class="input-field col s12">
                        
                        <?php echo Form::label('password', 'Password'); ?>

                        <?php echo Form::password('password', null, ['class' => 'validate', 'required']); ?>


                    </div>

                </div>

                <div class="row">
                    
                    <div class="col m12 col-center mt-15">
                    
                        <div class="col s6">
                            <a href="">Olvide mi contraseña</a>
                        </div> 
                        <div class="col s6">
                            <?php echo Form::submit('Log in', ['class' => 'btn btn-block btn-block-large waves-effect waves-light']); ?>

                        </div>

                    </div>

                </div>

            <?php echo Form::close(); ?>


    </div>

    <div class="row">
        
        <div class="col s5 col-center mt-50">
            
            <p id="response" class="center-align red-text"></p>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>