<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
	<?php echo $__env->make('layouts.nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row mt-30">
		<div class="col s12 border-bottom">
			<h5><b>Usuarios</b></h5>
		</div>
	</div>
	<div class="row">
			<div class="col s12">
				<div class="col m2 s4 plr-1">
					<button class="btn-block teal waves-effect waves-light btn" id="btn-admin-users-all">Todos</button>
				</div>
				<div class="col m2 s4 plr-1">
					<button class="btn-block phantom waves-effect waves-light btn" id="btn-admin-users-admin">Admin</button>
				</div>
				<div class="col m2 s4 plr-1">
					<button class="btn-block phantom waves-effect waves-light btn" id="btn-admin-users-users">User</button>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col s12 z-depth-1 white">
				<table class="bordered responsive-table">
					<thead>
						<tr>
							<th>Nombre</th>
							<th>Email</th>
							<th>Status</th>
							<th>Role</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody id="table-users-body">
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
							<td><?php echo e($user->name); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td>
								<?php if( $user->status == 1): ?>
								<span class='badge1 green white-text'>Activo</span>
								<?php else: ?>
								<span class='badge1 grey white-text'>Inactivo</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if( $user->role == 1 ): ?>
								<span class='badge1 teal white-text'>Admin</span>
								<?php else: ?>
								<span class='badge1 blue white-text'>User</span>
								<?php endif; ?>
							</td>
							<td>
								<a href="#!" class="user-view" data-id="<?php echo e($user->id); ?>"><i class="material-icons brown-text">receipt</i></a>
								<a href="#!" class="user-edit" data-id="<?php echo e($user->id); ?>"><i class="material-icons teal-text">edit</i></a>
								<a href="#!" class="user-delete" data-id="<?php echo e($user->id); ?>"><i class="material-icons red-text">delete</i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>

		<div class="fixed-action-btn">
		<a href="<?php echo e(route('users.create')); ?>" class="btn-floating btn-large waves-effect waves-light blue pull-right"><i class="material-icons">add</i></a>
		</div>

		<?php echo Form::open(['route' => 'users.getUsers', 'method' => 'POST', 'id' => 'form' ]); ?>

		<?php echo Form::hidden('type', 'all', ['id' => 'type']); ?>

		<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	$("button[id^='btn-admin-users-']").click(function(){

		var btn;
		if($(this).attr('id') == "btn-admin-users-all"){
			btn = "all";
		}else if($(this).attr('id') == "btn-admin-users-admin"){
			btn = "admin";
		}else{
			btn = "user";
		}

		$('#type').val(btn);
		var form = $('#form').serialize();

		$.ajax({

			url: 'users/getUsers',
			type: 'POST',
			data: form,
			success:function(response){
				$("#table-users-body").html(response);
				
			},
			error:function(response){
				alert(response);
			}

		});
	});
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>