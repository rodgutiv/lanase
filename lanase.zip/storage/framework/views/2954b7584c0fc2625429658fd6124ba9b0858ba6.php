<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php if(Auth::user()->isAdmin()): ?>
	<?php echo $__env->make('layouts.nav-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('layouts.nav-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row mt-30">
		<div class="col s12 border-bottom">
			<h5><b>Agregar nuevo area de investigación</b></h5>
		</div>
	</div>
	<div class="row">
		
		<?php echo Form::open(['route' => 'researcharea.store', 'method' => 'POST', 'class' => 'col s12 white z-depth-1', 'style' => 'padding: 30px', 'files' => true]); ?>

			<div class="row">
				<div class="input-field col s12 m4">
					<?php echo Form::label('title_es', 'Nombre (es)'); ?>

					<?php echo Form::text('title_es', null, ['class'=>'validate', 'required']); ?>					
				</div>
				<div class="input-field col s12 m4">
					<?php echo Form::label('title', 'Nombre (en)'); ?>

					<?php echo Form::text('title', null, ['class'=>'validate', 'required']); ?>					
				</div>
				<div class="col s12 m4">
					<div class="input-fields">
						<p>Display</p>
						<?php echo Form::radio('display', 1, false, ['id' => 'display1', 'class' => 'with-gap']); ?>

						<?php echo Form::label('display1', 'Si'); ?>

						<?php echo Form::radio('display', 0, false, ['id' => 'display2', 'class' => 'with-gap']); ?>

						<?php echo Form::label('display2', 'No'); ?>

					</div>
				</div>
			</div>
			<div class="row">
				<div class="input-field file-field">
					<div class="btn">
						<span>
							Imagen        
						</span>
						<?php echo Form::file('image'); ?>

					</div>
					<div class="file-path-wrapper">
						<?php echo Form::text('image',null,['class'=>'file-path validate','placeholder'=>'Selecciona una imagen']); ?>

					</div>
				</div>
			</div>
			<div class="input-field">
		      <?php echo Form::submit('Guardar',['class'=>'btn btn-block btn-block-large waves-effect waves-light']); ?>

		    </div>
		<?php echo Form::close(); ?>


	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>