@extends('panel.main')
@section('title','Dashboard')

@section('nav')
@if(Auth::user()->isAdmin())
	@include('layouts.nav-admin')
@else
	@include('layouts.nav-user')
@endif
@endsection

@section('content')

	<a href="{{ route('taxonomic.create') }}" class="btn waves-light waves-effect">Nuevo</a>

@endsection